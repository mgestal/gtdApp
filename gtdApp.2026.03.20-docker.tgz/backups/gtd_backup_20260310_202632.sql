/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.3-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: 127.0.0.1    Database: gtd
-- ------------------------------------------------------
-- Server version	11.8.3-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `filters`
--

DROP TABLE IF EXISTS `filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `expression` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_filter_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filters`
--

LOCK TABLES `filters` WRITE;
/*!40000 ALTER TABLE `filters` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `filters` VALUES
(1,'Caducadas','(fecha < hoy)','2026-03-04 08:41:35','2026-03-09 12:12:01'),
(2,'Plan semanal','fecha < hoy | fecha =1| fecha =2| fecha =3| fecha =4| fecha =5| fecha =6| fecha =7','2026-03-04 22:36:30','2026-03-04 22:38:11'),
(3,'Lista agenda','@Agenda','2026-03-04 22:39:07','2026-03-05 22:18:13'),
(4,'Archivo de seguimiento','@seguimiento & !f:\"Sometime\"','2026-03-04 22:40:40','2026-03-06 22:37:17'),
(5,'Lista EnEspera','pf:\"EnEspera\" | pf:\"Cobro Dietas/Facturas\" | pf:\"Prestamos\" | pf:\"Compras Internet\" | @EnEspera & !pf:\"Sometime\" & !inbox','2026-03-04 22:43:25','2026-03-05 22:24:18'),
(6,'Tareas con Deadline','@deadline & !p:Sometime & !f:\"04 - N-Anual\"','2026-03-04 23:35:53','2026-03-05 21:52:11'),
(7,'P. Acciones Pim-Pam','@NextAction & !p:Sometime & !inbox & @pocotiempo','2026-03-05 21:47:43','2026-03-05 21:50:21'),
(8,'P. Acciones Zombie','@PocaEnergia & !@PocoTiempo & @NextAction & !pf:Sometime & !inbox','2026-03-05 21:50:43','2026-03-05 21:53:04'),
(9,'P. Acciones Concentrado','@NextAction & @MuchaEnergia & !p:Sometime & inbox','2026-03-05 21:51:53','2026-03-05 22:24:26'),
(10,'P. Acciones casa','@nextaction & @celas','2026-03-06 21:30:09',NULL),
(11,'Próximas Acciones FIC','@nextaction & @fic','2026-03-06 21:30:42','2026-03-06 21:30:59'),
(15,'Lista NextActions','@nextaction','2026-03-08 11:26:06',NULL),
(16,'Tareas Pendientes','!done','2026-03-10 16:17:05',NULL),
(17,'Tareas olvidadas (más de 1 mes)','fecha <=-30','2026-03-10 16:46:27',NULL),
(18,'Tareas completadas','done','2026-03-10 16:48:46',NULL);
/*!40000 ALTER TABLE `filters` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `folders`
--

DROP TABLE IF EXISTS `folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `folders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_folder_parent_name` (`parent_id`,`name`),
  CONSTRAINT `fk_folders_parent` FOREIGN KEY (`parent_id`) REFERENCES `folders` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders`
--

LOCK TABLES `folders` WRITE;
/*!40000 ALTER TABLE `folders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `folders` VALUES
(1,NULL,'♲ Rutinas','2026-03-03 13:04:55'),
(2,NULL,'📅 Agenda','2026-03-03 13:06:47'),
(3,1,'01 - Diario','2026-03-03 18:48:48'),
(4,1,'02 - Semanal','2026-03-03 18:49:15'),
(5,1,'03 - Mensual','2026-03-03 18:49:42'),
(6,1,'04 - N-Anual','2026-03-03 18:50:03'),
(7,NULL,'GTD Folders','2026-03-03 18:55:52'),
(8,7,'EnEspera','2026-03-04 22:43:59'),
(9,8,'Dietas / Facturas','2026-03-04 22:51:50'),
(10,8,'Compras internet','2026-03-04 22:52:12'),
(11,7,'Single Actions Personal 🏡','2026-03-04 22:53:32'),
(12,7,'Single Actions Laboral','2026-03-04 22:53:57'),
(13,7,'Seguimiento','2026-03-04 22:54:42'),
(14,13,'Próxima semana','2026-03-04 22:54:53'),
(15,13,'Próximos meses','2026-03-04 22:55:03'),
(16,NULL,'Area Personal 🚶','2026-03-04 22:55:43'),
(17,NULL,'Area Laboral: UDC 🎓','2026-03-04 22:55:59'),
(18,7,'Sometime','2026-03-04 22:57:08'),
(19,18,'ADTV','2026-03-04 22:57:23'),
(20,18,'🔜 EstaSemanaNo','2026-03-04 22:57:45'),
(21,18,'✅ Checklists','2026-03-04 22:58:17');
/*!40000 ALTER TABLE `folders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `folder_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `active_name` varchar(255) GENERATED ALWAYS AS (if(`archived` = 0,`name`,NULL)) STORED,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_project_active_name` (`active_name`),
  KEY `idx_projects_folder` (`folder_id`),
  KEY `idx_projects_archived` (`archived`),
  CONSTRAINT `fk_projects_folder` FOREIGN KEY (`folder_id`) REFERENCES `folders` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projects` VALUES
(5,2,'Cumpleaños',NULL,0,'Cumpleaños','2026-03-03 13:06:59','2026-03-04 12:25:23'),
(7,4,'Revisión GTD','Objetivos: \r\n\r\n* todas las tareas introducidas en sistema GTD siguen siendo relevantes\r\n* fechas objetivas\r\n* tareas/proyectos a realizar la semana entrante',0,'Revisión GTD','2026-03-03 16:05:57','2026-03-06 22:58:18'),
(8,2,'Citas Médicas','Cita Médicas',0,'Citas Médicas','2026-03-03 22:31:22','2026-03-06 09:04:21'),
(9,2,'Santos Familia',NULL,0,'Santos Familia','2026-03-06 22:43:00','2026-03-06 22:43:17'),
(12,21,'TV',NULL,0,'TV','2026-03-08 10:46:36',NULL),
(13,17,'Cátedra',NULL,0,'Cátedra','2026-03-08 11:08:21','2026-03-08 11:08:41'),
(15,17,'Desadscripción CITIC',NULL,0,'Desadscripción CITIC','2026-03-08 11:24:03','2026-03-08 11:24:17'),
(16,17,'Imatus',NULL,0,'Imatus','2026-03-09 11:17:48',NULL),
(21,16,'Parterre',NULL,0,'Parterre','2026-03-09 12:15:40','2026-03-09 12:15:54');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `subtasks`
--

DROP TABLE IF EXISTS `subtasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subtasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_subtasks_task` (`task_id`),
  KEY `idx_subtasks_due` (`due_date`),
  KEY `idx_subtasks_completed` (`completed_at`),
  CONSTRAINT `fk_subtasks_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subtasks`
--

LOCK TABLES `subtasks` WRITE;
/*!40000 ALTER TABLE `subtasks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `subtasks` VALUES
(3,29,'Brainstorming','Añadir ideas a bandeja de entrada',NULL,'2026-03-04 20:45:39',NULL),
(4,29,'Procesar inbox correo electrónico',NULL,NULL,'2026-03-04 20:46:39',NULL),
(5,29,'Procesar inbox GTD',NULL,NULL,'2026-03-04 20:47:06',NULL),
(6,30,'Marcar tareas completadas',NULL,NULL,'2026-03-04 21:03:19',NULL),
(7,30,'Actualizar información',NULL,NULL,'2026-03-04 21:03:32',NULL),
(8,31,'Revisión de calendario',NULL,NULL,'2026-03-04 21:05:56',NULL),
(9,31,'Revisión fichero de seguimiento',NULL,NULL,'2026-03-04 21:06:12',NULL),
(10,31,'Asignación de siguientes acciones',NULL,NULL,'2026-03-04 21:06:26',NULL),
(11,32,'Actualizar fechas (posponer si es necesario)',NULL,NULL,'2026-03-04 21:33:09',NULL),
(12,32,'Establecer nuevas NextAction para finalizar proyectos',NULL,NULL,'2026-03-04 21:33:34',NULL),
(13,32,'Mover a otras listas (EnEspera, EstaSemanaNo, ADTV...)',NULL,NULL,'2026-03-04 21:37:13',NULL),
(14,33,'Marcar elementos ya recibidos',NULL,NULL,'2026-03-04 21:38:28',NULL),
(15,33,'Realizar llamadas/mail para recordatorios',NULL,NULL,'2026-03-04 21:39:04',NULL),
(16,33,'Establecer nuevas acciones para recordatorios',NULL,NULL,'2026-03-04 21:39:33',NULL),
(17,34,'Incubar proyectos (EstaSemanaNo, ADTV)',NULL,NULL,'2026-03-04 21:40:23',NULL),
(18,34,'Confirmar que existe NextAction en todos',NULL,NULL,'2026-03-04 21:40:40',NULL),
(19,34,'Actualizar información',NULL,NULL,'2026-03-04 21:40:54',NULL),
(20,34,'Archivar finalizados',NULL,NULL,'2026-03-04 21:41:06',NULL),
(21,35,'Lista EstaSemanaNo: considerar activación o ADTV',NULL,NULL,'2026-03-04 21:41:37',NULL),
(22,35,'Lista ADTV (revisión ligera): considerar activar o eliminar',NULL,NULL,'2026-03-04 21:42:11',NULL),
(23,36,'Rutinas',NULL,NULL,'2026-03-04 21:43:14',NULL),
(24,36,'Áreas de interés',NULL,NULL,'2026-03-04 21:43:26',NULL),
(25,36,'Películas, libros, regalos...',NULL,NULL,'2026-03-04 21:43:46',NULL),
(26,37,'Analizar qué ha ido bien (y mal) esta semana y hacer ajustes necesarios',NULL,NULL,'2026-03-04 21:45:50',NULL);
/*!40000 ALTER TABLE `subtasks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tag_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tags` VALUES
(1,'celas','2026-03-03 22:19:38'),
(2,'agenda','2026-03-03 22:45:55'),
(3,'casa','2026-03-03 22:45:55'),
(4,'pocaEnergia','2026-03-03 23:18:01'),
(5,'muchoTiempo','2026-03-03 23:18:01'),
(6,'ordenador','2026-03-03 23:27:03'),
(8,'periodica','2026-03-04 21:56:11'),
(9,'EnEspera','2026-03-04 22:44:42'),
(11,'beni','2026-03-06 21:51:05'),
(13,'movistartv','2026-03-08 10:37:33'),
(14,'NextAction','2026-03-08 11:09:03'),
(15,'EnSeguimiento','2026-03-09 11:18:47'),
(16,'recados','2026-03-10 16:19:39');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `task_tags`
--

DROP TABLE IF EXISTS `task_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_tags` (
  `task_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`task_id`,`tag_id`),
  KEY `idx_tasktags_tag` (`tag_id`),
  CONSTRAINT `fk_tasktags_tag` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tasktags_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_tags`
--

LOCK TABLES `task_tags` WRITE;
/*!40000 ALTER TABLE `task_tags` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `task_tags` VALUES
(19,1),
(40,2),
(50,2),
(52,2),
(61,2),
(71,2),
(78,2),
(19,4),
(19,5),
(20,6),
(40,8),
(85,9),
(19,11),
(52,11),
(69,13),
(94,14),
(95,14),
(53,15),
(79,15),
(86,16),
(92,16);
/*!40000 ALTER TABLE `task_tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `folder_id` int(11) DEFAULT NULL,
  `title` varchar(500) NOT NULL,
  `notes` text DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  `last_completed_at` datetime DEFAULT NULL,
  `recurrence_rule` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tasks_project` (`project_id`),
  KEY `idx_tasks_due` (`due_date`),
  KEY `idx_tasks_completed` (`completed_at`),
  KEY `idx_tasks_folder` (`folder_id`),
  FULLTEXT KEY `ftx_tasks_title_notes` (`title`,`notes`),
  CONSTRAINT `fk_tasks_folder` FOREIGN KEY (`folder_id`) REFERENCES `folders` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tasks_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tasks` VALUES
(1,5,NULL,'Cumpleaños Nuria Pet',NULL,'2027-03-03','2026-03-03 15:36:58',NULL,'2026-03-03 19:37:19','FREQ=YEARLY;INTERVAL=1'),
(2,5,NULL,'Cumpleaños Oliver Concheiro',NULL,'2027-03-03','2026-03-03 15:37:53',NULL,'2026-03-03 19:37:22','FREQ=YEARLY;INTERVAL=1'),
(3,5,NULL,'Cumpleaños Iria',NULL,'2026-07-25','2026-03-03 15:56:21',NULL,NULL,'FREQ=YEARLY'),
(4,5,NULL,'Cumpleaños Paula',NULL,'2026-06-15','2026-03-03 15:57:29',NULL,NULL,'FREQ=Yearly'),
(5,5,NULL,'Cumpleaños Noemí',NULL,'2026-09-21','2026-03-03 16:00:19',NULL,NULL,'FREQ=YEARLY;INTERVAL=1'),
(6,5,NULL,'Cumpleaños Raúl',NULL,'2026-08-03','2026-03-03 16:00:51',NULL,NULL,'FREQ=YEARLY;INTERVAL=1'),
(19,NULL,3,'Paseo Beni',NULL,'2026-03-11','2026-03-03 23:25:40',NULL,'2026-03-10 17:44:29','FREQ=DAILY;INTERVAL=1'),
(20,NULL,5,'Actualizar Excel gastos',NULL,'2026-03-28','2026-03-03 23:27:03',NULL,'2026-03-04 00:29:02','FREQ=MONTHLY;BYMONTHDAY=28;INTERVAL=1'),
(29,7,NULL,'01 - Vaciado bandejas entrada',NULL,'2026-03-13','2026-03-04 20:27:08',NULL,'2026-03-06 22:50:09','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(30,7,NULL,'02 - Revisión lista NextActions',NULL,'2026-03-13','2026-03-04 20:48:26',NULL,'2026-03-06 22:50:08','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(31,7,NULL,'03 - Revisión  Agenda (eventos futuros)',NULL,'2026-03-13','2026-03-04 20:50:57',NULL,'2026-03-06 22:50:05','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(32,7,NULL,'04 - Revisión Agenda (eventos pasados)',NULL,'2026-03-13','2026-03-04 20:51:46',NULL,'2026-03-06 22:50:04','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(33,7,NULL,'05 - Revisión lista EnEspera',NULL,'2026-03-13','2026-03-04 20:52:12',NULL,'2026-03-06 22:50:04','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(34,7,NULL,'06 - Revisión lista proyectos',NULL,'2026-03-13','2026-03-04 20:53:41',NULL,'2026-03-06 22:50:03','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(35,7,NULL,'07 - Revisión listas ADTV/SomeTime',NULL,'2026-03-13','2026-03-04 20:58:55',NULL,'2026-03-06 22:50:02','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(36,7,NULL,'08 - Revisión listas comprobación',NULL,'2026-03-13','2026-03-04 21:42:54',NULL,'2026-03-06 22:50:02','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(37,7,NULL,'09 - Análisis sistema GTD',NULL,'2026-03-13','2026-03-04 21:45:00',NULL,'2026-03-06 22:50:01','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(38,7,NULL,'10 - Fase creativa: Brainstorming para añadir nuevas ideas',NULL,'2026-03-13','2026-03-04 21:46:18',NULL,'2026-03-06 22:50:00','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(40,7,NULL,'00 - Revisión semanal GTD',NULL,'2026-03-20','2026-03-04 21:56:11',NULL,'2026-03-10 17:21:15','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(50,NULL,2,'10.000 días desde 2/03/2001',NULL,'2028-07-18','2026-03-05 19:01:57',NULL,NULL,NULL),
(51,NULL,8,'Honorarios CITIC',NULL,NULL,'2026-03-05 21:54:32',NULL,NULL,NULL),
(52,NULL,4,'Entrenamiento Beni en Gaia (19:00 - 20:00)',NULL,'2026-03-13','2026-03-06 21:51:43',NULL,'2026-03-06 22:52:07','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1'),
(53,NULL,6,'Revisar publicación Complementos Excelencia Xunta','http://www.acsug.es/gl/search/node/excelencia','2027-02-15','2026-03-06 22:33:44',NULL,NULL,'FREQ=YEARLY;INTERVAL=4'),
(56,9,NULL,'Santa Paula',NULL,NULL,'2026-03-06 22:43:26',NULL,NULL,NULL),
(61,9,NULL,'San Marcos',NULL,'2026-05-25','2026-03-06 23:00:31',NULL,NULL,'FREQ=YEARLY;INTERVAL=1'),
(69,12,NULL,'Rondallas',NULL,NULL,'2026-03-08 10:46:36',NULL,NULL,NULL),
(70,13,NULL,'Preparar presentacion normativa',NULL,'2026-03-09','2026-03-08 11:08:21','2026-03-09 13:02:12',NULL,NULL),
(71,13,NULL,'Reunión con gerente residencias (hora: 13:30)',NULL,'2026-03-10','2026-03-08 11:09:48','2026-03-10 16:10:25',NULL,NULL),
(75,15,NULL,'Enviar correo confirmando desascripcion CITIC',NULL,NULL,'2026-03-08 11:24:03','2026-03-09 13:01:31',NULL,NULL),
(76,15,NULL,'Concretar reunión con Fernando para confirmar inexistencia problemas',NULL,NULL,'2026-03-08 11:24:35','2026-03-09 13:01:16',NULL,NULL),
(77,15,NULL,'Solicitar adscripción CITEEC',NULL,NULL,'2026-03-08 11:24:55',NULL,NULL,NULL),
(78,16,NULL,'Curso Imatus 07-04-2026 (16:00 - 20:00)',NULL,NULL,'2026-03-09 11:17:48',NULL,NULL,NULL),
(79,16,NULL,'Preparar transparencias con apps de seguridad',NULL,'2026-04-30','2026-03-09 11:18:47',NULL,NULL,NULL),
(85,15,NULL,'Confirmación desacripción CITIC',NULL,NULL,'2026-03-09 12:01:47',NULL,NULL,NULL),
(86,21,NULL,'Comprar malla antihierba',NULL,NULL,'2026-03-09 12:15:40',NULL,NULL,NULL),
(87,21,NULL,'Colocar malla antihierba y fijación exterior',NULL,NULL,'2026-03-09 12:16:12',NULL,NULL,NULL),
(88,21,NULL,'Cubrir malla con piedra blanca',NULL,NULL,'2026-03-09 12:16:29',NULL,NULL,NULL),
(89,21,NULL,'Rellenar maceta con tierra + tierra vegetal',NULL,NULL,'2026-03-09 12:17:07',NULL,NULL,NULL),
(90,21,NULL,'Agujerear maceta para drenaje de agua',NULL,NULL,'2026-03-09 12:17:28',NULL,NULL,NULL),
(91,21,NULL,'Comprar y colocar plantas decorativas',NULL,NULL,'2026-03-09 12:17:42',NULL,NULL,NULL),
(92,NULL,16,'Recoger cerezo en vivero',NULL,NULL,'2026-03-10 16:20:44',NULL,NULL,NULL),
(94,NULL,17,'Tramitar dieta de O Camiño do Inglés a través de FUAC',NULL,NULL,'2026-03-10 19:18:02',NULL,NULL,NULL),
(95,NULL,17,'Tramitar dieta comida navidad a través de FUAC',NULL,NULL,'2026-03-10 19:18:29',NULL,NULL,NULL);
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping events for database 'gtd'
--

--
-- Dumping routines for database 'gtd'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-10 20:26:32
