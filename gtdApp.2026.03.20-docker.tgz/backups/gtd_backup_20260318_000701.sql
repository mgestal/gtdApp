/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: 127.0.0.1    Database: gtd
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-0+deb13u1 from Debian

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `filters`
--

DROP TABLE IF EXISTS `filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `expression` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_filter_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filters`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `filters` WRITE;
/*!40000 ALTER TABLE `filters` DISABLE KEYS */;
INSERT INTO `filters` VALUES
(1,'Caducadas','(fecha < hoy)','2026-03-04 08:41:35','2026-03-17 10:17:54'),
(2,'Plan semanal','fecha < hoy | fecha =1| fecha =2| fecha =3| fecha =4| fecha =5| fecha =6| fecha =7','2026-03-04 22:36:30','2026-03-04 22:38:11'),
(3,'Lista agenda','@Agenda','2026-03-04 22:39:07','2026-03-05 22:18:13'),
(4,'Archivo de seguimiento','@enseguimiento & !f:\"Sometime\"','2026-03-04 22:40:40','2026-03-10 22:29:31'),
(5,'Lista EnEspera','fa:EnEspera & @EnEspera  & !inbox','2026-03-04 22:43:25','2026-03-17 10:26:02'),
(6,'Tareas con Deadline','@deadline & !p:Sometime','2026-03-04 23:35:53','2026-03-17 10:27:34'),
(7,'P. Acciones Pim-Pam','@NextAction & !p:Sometime & !inbox & @pocotiempo','2026-03-05 21:47:43','2026-03-05 21:50:21'),
(8,'P. Acciones Zombie','@PocaEnergia & !@PocoTiempo & @NextAction & !pf:Sometime & !inbox','2026-03-05 21:50:43','2026-03-05 21:53:04'),
(9,'P. Acciones Concentrado','@NextAction & @MuchaEnergia & !fa:Sometime & !inbox','2026-03-05 21:51:53','2026-03-17 12:59:47'),
(10,'P. Acciones casa','@nextaction & @celas','2026-03-06 21:30:09',NULL),
(11,'Próximas Acciones FIC','@nextaction & @fic','2026-03-06 21:30:42','2026-03-06 21:30:59'),
(15,'Lista NextActions','@nextaction & !fr:sometime','2026-03-08 11:26:06','2026-03-16 22:54:37'),
(16,'Tareas Pendientes','!done','2026-03-10 16:17:05',NULL),
(17,'Tareas olvidadas (más de 1 mes)','fecha <=-30','2026-03-10 16:46:27',NULL),
(18,'Tareas completadas','done','2026-03-10 16:48:46',NULL),
(20,'Lista SomeTime','@sometime | fa:sometime','2026-03-11 11:33:11','2026-03-11 11:34:21'),
(21,'Archivo de seguimiento: YA viables','(fecha <= hoy) & @EnSeguimiento','2026-03-17 10:21:51','2026-03-17 10:22:09'),
(22,'P. Acciones a secas','@NextAction & !(@PocoTiempo | @MuchoTiempo) & !(@PocaEnergia | @MuchaEnergia) & !fa:SomeTime','2026-03-17 10:33:09','2026-03-17 12:22:33'),
(23,'TMI','@tmi &!fa:sometime','2026-03-17 12:37:25',NULL);
/*!40000 ALTER TABLE `filters` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `folders`
--

DROP TABLE IF EXISTS `folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `folders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_folder_parent_name` (`parent_id`,`name`),
  CONSTRAINT `fk_folders_parent` FOREIGN KEY (`parent_id`) REFERENCES `folders` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folders`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `folders` WRITE;
/*!40000 ALTER TABLE `folders` DISABLE KEYS */;
INSERT INTO `folders` VALUES
(1,NULL,'♲ Rutinas','2026-03-03 13:04:55'),
(2,NULL,'🗃️ Agenda','2026-03-03 13:06:47'),
(3,1,'01 - Diario','2026-03-03 18:48:48'),
(4,1,'02 - Semanal','2026-03-03 18:49:15'),
(5,1,'03 - Mensual','2026-03-03 18:49:42'),
(6,1,'04 - N-Anual','2026-03-03 18:50:03'),
(7,NULL,'GTD Folders','2026-03-03 18:55:52'),
(8,7,'EnEspera','2026-03-04 22:43:59'),
(9,8,'Dietas / Facturas','2026-03-04 22:51:50'),
(10,8,'Compras internet','2026-03-04 22:52:12'),
(13,7,'Seguimiento','2026-03-04 22:54:42'),
(14,13,'Próxima semana','2026-03-04 22:54:53'),
(15,13,'Próximos meses','2026-03-04 22:55:03'),
(16,NULL,'Area Personal 🚶','2026-03-04 22:55:43'),
(17,NULL,'Area Laboral: UDC 🎓','2026-03-04 22:55:59'),
(18,7,'Sometime','2026-03-04 22:57:08'),
(19,18,'ADTV','2026-03-04 22:57:23'),
(20,18,'🔜 EstaSemanaNo','2026-03-04 22:57:45'),
(21,18,'✅ Checklists','2026-03-04 22:58:17'),
(23,17,'Docencia','2026-03-10 21:04:25'),
(24,23,'MAD','2026-03-10 21:10:21'),
(25,17,'Research','2026-03-17 12:32:20');
/*!40000 ALTER TABLE `folders` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `imported_calendar_events`
--

DROP TABLE IF EXISTS `imported_calendar_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `imported_calendar_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `google_event_id` varchar(255) NOT NULL,
  `task_id` int(11) NOT NULL,
  `imported_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `google_event_id` (`google_event_id`),
  KEY `idx_imported_calendar_events_task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imported_calendar_events`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `imported_calendar_events` WRITE;
/*!40000 ALTER TABLE `imported_calendar_events` DISABLE KEYS */;
INSERT INTO `imported_calendar_events` VALUES
(1,'todoist6805024i2202204634uf5846d407a744010a490fca5a2c367ee_20260316',151,'2026-03-16 13:28:59'),
(2,'6sqjid1j6or66b9p6go30b9kcgpjgbb2cdj36b9g6lhm2opg69h30eb468_20260320T180000Z',152,'2026-03-16 13:28:59'),
(3,'todoist6805024i2207681404u0b9d8d83974443b8add8f3c8e4d96841_20260321',153,'2026-03-16 13:29:29'),
(4,'todoist6805024i3111061937u2b5b02e96a6247efa64c9d0dabc1267b_20260321T190000Z',154,'2026-03-16 13:29:29'),
(5,'3p8jb6e4dja7l8bnfbnov4qp6d',155,'2026-03-16 13:29:29'),
(6,'2iifs9kd5r9t7kg582tp1om0j0',156,'2026-03-16 13:29:29'),
(7,'todoist6805024i2582695840u88616e752b7e4537a5456c1f46617a39_20260326',157,'2026-03-16 13:29:29'),
(8,'0o04njajh52su16qmmgbuap0n0',158,'2026-03-16 13:29:29'),
(9,'34btj9p5ioohun5m23sv33j0v2',159,'2026-03-16 13:29:29'),
(10,'todoist6805024i3029341865uc9d036daba924518a4e9631ce8e57c43_20260327',160,'2026-03-16 13:29:29'),
(11,'6sqjid1j6or66b9p6go30b9kcgpjgbb2cdj36b9g6lhm2opg69h30eb468_20260327T180000Z',168,'2026-03-16 20:36:37'),
(12,'todoist6805024i1663267650uf8baf43c4acd4f4282c246fbaeadf4db_20260328',169,'2026-03-16 20:36:37'),
(13,'todoist6805024i3474824077uc9bf854874884bbd94e2335c7e36e16c_20260328',170,'2026-03-16 20:36:37'),
(14,'todoist6805024i3474824760u6245afcc00624d4bba9afbb7ff3ab182_20260328',171,'2026-03-16 20:36:37'),
(15,'todoist6805024i3474825363ucf0b83ff2e89415f957e7db1944d8894_20260328',172,'2026-03-16 20:36:37'),
(16,'todoist6805024i3888940164ufd055a75a8164139ad448b519049a9d4_20260328',173,'2026-03-16 20:36:37'),
(17,'todoist6805024i52654914u5e94828fe561471ea505a816cd821957_20260328',174,'2026-03-16 20:36:37'),
(18,'todoist6805024i2341916571u87caae6c9ddd473dbec8f4396dad37b5_20260401',175,'2026-03-16 20:36:37'),
(19,'todoist6805024i2345206336u41034f64f85b429cb2d11365e9134369_20260401',176,'2026-03-16 20:36:37'),
(20,'todoist6805024i2345205687u01e5bbfeb07446f9bc94785f848f3192_20260402',177,'2026-03-16 20:36:37');
/*!40000 ALTER TABLE `imported_calendar_events` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `imported_emails`
--

DROP TABLE IF EXISTS `imported_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `imported_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gmail_message_id` varchar(255) NOT NULL,
  `gmail_thread_id` varchar(255) DEFAULT NULL,
  `task_id` int(11) NOT NULL,
  `imported_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `gmail_message_id` (`gmail_message_id`),
  KEY `idx_imported_emails_task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imported_emails`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `imported_emails` WRITE;
/*!40000 ALTER TABLE `imported_emails` DISABLE KEYS */;
INSERT INTO `imported_emails` VALUES
(2,'19ce7b5c09a8e10c','19ce7b5c09a8e10c',180,'2026-03-16 22:53:20'),
(3,'19ce3f7f57d41500','19ce3f7f57d41500',181,'2026-03-16 22:53:21'),
(4,'19cf8f61476ebd3a','19cf8f61476ebd3a',196,'2026-03-17 00:23:47'),
(5,'19cf669093dbe83d','19cf669093dbe83d',197,'2026-03-17 00:23:47'),
(6,'19cf668fce658013','19cf668fce658013',198,'2026-03-17 00:23:47'),
(7,'19cf668d5a794a6a','19cf668d5a794a6a',199,'2026-03-17 00:23:47'),
(8,'19cf5e1ac82f238c','19cf5e1ac82f238c',200,'2026-03-17 00:23:48'),
(9,'19cfc126f77b2e1b','19cfc126f77b2e1b',220,'2026-03-17 16:25:30');
/*!40000 ALTER TABLE `imported_emails` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `folder_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `archived_at` datetime DEFAULT NULL,
  `active_name` varchar(255) GENERATED ALWAYS AS (if(`archived` = 0,`name`,NULL)) STORED,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_project_active_name` (`active_name`),
  KEY `idx_projects_folder` (`folder_id`),
  KEY `idx_projects_archived` (`archived`),
  KEY `idx_projects_archived_at` (`archived_at`),
  CONSTRAINT `fk_projects_folder` FOREIGN KEY (`folder_id`) REFERENCES `folders` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES
(5,2,'Cumpleaños',NULL,0,NULL,'Cumpleaños','2026-03-03 13:06:59','2026-03-04 12:25:23'),
(7,4,'Revisión GTD','Objetivos: \r\n\r\n* todas las tareas introducidas en sistema GTD siguen siendo relevantes\r\n* fechas objetivas\r\n* tareas/proyectos a realizar la semana entrante',1,'2026-03-17 23:57:24',NULL,'2026-03-03 16:05:57','2026-03-17 22:57:24'),
(8,2,'Citas Médicas','Cita Médicas',0,NULL,'Citas Médicas','2026-03-03 22:31:22','2026-03-06 09:04:21'),
(9,2,'Santos Familia',NULL,0,NULL,'Santos Familia','2026-03-06 22:43:00','2026-03-06 22:43:17'),
(12,21,'PeliculasTV',NULL,0,NULL,'PeliculasTV','2026-03-08 10:46:36','2026-03-16 19:43:32'),
(13,17,'Cátedra',NULL,0,NULL,'Cátedra','2026-03-08 11:08:21','2026-03-08 11:08:41'),
(15,17,'Desadscripción CITIC',NULL,0,NULL,'Desadscripción CITIC','2026-03-08 11:24:03','2026-03-08 11:24:17'),
(16,17,'Imatus',NULL,0,NULL,'Imatus','2026-03-09 11:17:48',NULL),
(21,16,'Parterre jardín',NULL,0,NULL,'Parterre jardín','2026-03-09 12:15:40','2026-03-16 21:46:02'),
(25,21,'Libros',NULL,0,NULL,'Libros','2026-03-11 20:31:10',NULL),
(27,17,'TalentosInclusivos2026',NULL,0,NULL,'TalentosInclusivos2026','2026-03-16 19:14:46','2026-03-16 19:15:37'),
(28,16,'ViajeBayuela (04-2026)',NULL,0,NULL,'ViajeBayuela (04-2026)','2026-03-16 19:16:53','2026-03-16 19:18:29'),
(30,21,'SeriesTV',NULL,0,NULL,'SeriesTV','2026-03-16 19:42:49','2026-03-16 19:42:56'),
(31,21,'Lugares',NULL,0,NULL,'Lugares','2026-03-16 22:57:11',NULL),
(33,25,'Artículo Radón',NULL,0,NULL,'Artículo Radón','2026-03-17 12:35:27',NULL),
(34,17,'Curso LLM Citeec',NULL,0,NULL,'Curso LLM Citeec','2026-03-17 12:47:43',NULL),
(35,16,'Implementación sistema GTD',NULL,0,NULL,'Implementación sistema GTD','2026-03-17 12:52:38',NULL),
(36,16,'BautizoGabi',NULL,0,NULL,'BautizoGabi','2026-03-17 15:27:44','2026-03-17 15:30:51'),
(37,16,'Obra Diego',NULL,0,NULL,'Obra Diego','2026-03-17 15:33:22','2026-03-17 15:33:46');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `subtasks`
--

DROP TABLE IF EXISTS `subtasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subtasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_subtasks_task` (`task_id`),
  KEY `idx_subtasks_due` (`due_date`),
  KEY `idx_subtasks_completed` (`completed_at`),
  CONSTRAINT `fk_subtasks_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subtasks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `subtasks` WRITE;
/*!40000 ALTER TABLE `subtasks` DISABLE KEYS */;
INSERT INTO `subtasks` VALUES
(3,29,'Brainstorming','Añadir ideas a bandeja de entrada',NULL,'2026-03-04 20:45:39',NULL),
(4,29,'Procesar inbox correo electrónico',NULL,NULL,'2026-03-04 20:46:39',NULL),
(5,29,'Procesar inbox GTD',NULL,NULL,'2026-03-04 20:47:06',NULL),
(6,30,'Marcar tareas completadas',NULL,NULL,'2026-03-04 21:03:19',NULL),
(7,30,'Actualizar información',NULL,NULL,'2026-03-04 21:03:32',NULL),
(8,31,'Revisión de calendario',NULL,NULL,'2026-03-04 21:05:56',NULL),
(9,31,'Revisión fichero de seguimiento',NULL,NULL,'2026-03-04 21:06:12',NULL),
(10,31,'Asignación de siguientes acciones',NULL,NULL,'2026-03-04 21:06:26',NULL),
(11,32,'Actualizar fechas (posponer si es necesario)',NULL,NULL,'2026-03-04 21:33:09',NULL),
(12,32,'Establecer nuevas NextAction para finalizar proyectos',NULL,NULL,'2026-03-04 21:33:34',NULL),
(13,32,'Mover a otras listas (EnEspera, EstaSemanaNo, ADTV...)',NULL,NULL,'2026-03-04 21:37:13',NULL),
(14,33,'Marcar elementos ya recibidos',NULL,NULL,'2026-03-04 21:38:28',NULL),
(15,33,'Realizar llamadas/mail para recordatorios',NULL,NULL,'2026-03-04 21:39:04',NULL),
(16,33,'Establecer nuevas acciones para recordatorios',NULL,NULL,'2026-03-04 21:39:33',NULL),
(17,34,'Incubar proyectos (EstaSemanaNo, ADTV)',NULL,NULL,'2026-03-04 21:40:23',NULL),
(18,34,'Confirmar que existe NextAction en todos',NULL,NULL,'2026-03-04 21:40:40',NULL),
(19,34,'Actualizar información',NULL,NULL,'2026-03-04 21:40:54',NULL),
(20,34,'Archivar finalizados',NULL,NULL,'2026-03-04 21:41:06',NULL),
(21,35,'Lista EstaSemanaNo: considerar activación o ADTV',NULL,NULL,'2026-03-04 21:41:37',NULL),
(22,35,'Lista ADTV (revisión ligera): considerar activar o eliminar',NULL,NULL,'2026-03-04 21:42:11',NULL),
(23,36,'Rutinas',NULL,NULL,'2026-03-04 21:43:14',NULL),
(24,36,'Áreas de interés',NULL,NULL,'2026-03-04 21:43:26',NULL),
(25,36,'Películas, libros, regalos...',NULL,NULL,'2026-03-04 21:43:46',NULL),
(26,37,'Analizar qué ha ido bien (y mal) esta semana y hacer ajustes necesarios',NULL,NULL,'2026-03-04 21:45:50',NULL),
(30,97,'Descargar fichero nómina','http://persoal.udc.es',NULL,'2026-03-10 20:39:00',NULL),
(31,97,'Imprimir nómina',NULL,NULL,'2026-03-10 20:39:12',NULL),
(32,97,'Archivar nómina',NULL,NULL,'2026-03-10 20:39:19',NULL),
(33,103,'Docencia.web en GoogleDrive',NULL,NULL,'2026-03-10 21:20:18',NULL),
(34,103,'Documento horarios.docx',NULL,NULL,'2026-03-10 21:20:37',NULL),
(35,121,'Imprimir en FIC',NULL,NULL,'2026-03-16 21:48:32',NULL),
(36,121,'Anillar',NULL,NULL,'2026-03-16 21:49:11',NULL),
(39,237,'Descargar archivo nómina',NULL,NULL,'2026-03-17 22:18:50',NULL),
(40,237,'Imprimir archivo nómina (a5)',NULL,NULL,'2026-03-17 22:19:08',NULL),
(41,237,'Archivar nómina mes',NULL,NULL,'2026-03-17 22:19:29',NULL);
/*!40000 ALTER TABLE `subtasks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(80) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tag_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES
(1,'Celas','Lugar','2026-03-03 22:19:38'),
(2,'agenda','Sistema GTD','2026-03-03 22:45:55'),
(4,'PocoTiempo','Energía','2026-03-03 23:18:01'),
(5,'MuchoTiempo','Energía','2026-03-03 23:18:01'),
(6,'ordenador','Herramienta','2026-03-03 23:27:03'),
(8,'periodica','Sistema GTD','2026-03-04 21:56:11'),
(9,'EnEspera','Sistema GTD','2026-03-04 22:44:42'),
(11,'Beni','Persona','2026-03-06 21:51:05'),
(13,'movistartv','TV','2026-03-08 10:37:33'),
(14,'NextAction','Sistema GTD','2026-03-08 11:09:03'),
(15,'EnSeguimiento','Sistema GTD','2026-03-09 11:18:47'),
(16,'recados','Lugar','2026-03-10 16:19:39'),
(17,'Citeec','Lugar','2026-03-10 21:09:31'),
(18,'AmazonPrime','TV','2026-03-10 21:12:26'),
(21,'telegrambot','Inbox','2026-03-13 20:54:17'),
(22,'Bayuela','Lugar','2026-03-14 23:37:20'),
(23,'email','Herramienta','2026-03-14 23:43:41'),
(24,'PocaEnergia','Energía','2026-03-16 08:49:23'),
(25,'inbox.calendar','Inbox','2026-03-16 12:28:59'),
(26,'Netflix','TV','2026-03-16 19:47:40'),
(27,'inbox.email','Inbox','2026-03-16 21:53:34'),
(28,'inbox','Inbox','2026-03-16 22:28:01'),
(29,'inbox.gmail','Inbox','2026-03-16 23:23:47'),
(30,'tmi',NULL,'2026-03-17 12:36:09'),
(32,'MuchaEnergia',NULL,'2026-03-17 12:58:19'),
(33,'fic',NULL,'2026-03-17 15:25:30'),
(34,'Julián','Persona','2026-03-17 18:16:42');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `task_tags`
--

DROP TABLE IF EXISTS `task_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_tags` (
  `task_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`task_id`,`tag_id`),
  KEY `idx_tasktags_tag` (`tag_id`),
  CONSTRAINT `fk_tasktags_tag` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tasktags_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `task_tags` WRITE;
/*!40000 ALTER TABLE `task_tags` DISABLE KEYS */;
INSERT INTO `task_tags` VALUES
(19,1),
(144,1),
(148,1),
(40,2),
(50,2),
(56,2),
(61,2),
(71,2),
(78,2),
(96,2),
(122,2),
(134,2),
(136,2),
(137,2),
(139,2),
(151,2),
(152,2),
(153,2),
(155,2),
(156,2),
(158,2),
(159,2),
(173,2),
(174,2),
(201,2),
(202,2),
(203,2),
(204,2),
(208,2),
(209,2),
(223,2),
(236,2),
(215,4),
(216,4),
(229,4),
(237,4),
(19,5),
(212,5),
(236,5),
(96,6),
(40,8),
(51,9),
(85,9),
(119,9),
(123,9),
(131,9),
(132,9),
(145,9),
(163,9),
(222,9),
(19,11),
(69,13),
(98,14),
(104,14),
(106,14),
(138,14),
(205,14),
(212,14),
(238,14),
(239,14),
(53,15),
(79,15),
(102,15),
(103,15),
(140,15),
(142,15),
(148,15),
(183,15),
(210,15),
(211,15),
(86,16),
(92,16),
(98,17),
(100,18),
(167,18),
(147,21),
(148,21),
(161,21),
(231,21),
(232,21),
(140,22),
(19,24),
(216,24),
(237,24),
(151,25),
(152,25),
(153,25),
(155,25),
(173,25),
(174,25),
(166,26),
(156,28),
(159,28),
(196,28),
(220,29),
(205,30),
(215,30),
(212,32),
(213,32),
(217,32),
(236,32),
(220,33),
(237,33),
(231,34);
/*!40000 ALTER TABLE `task_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `folder_id` int(11) DEFAULT NULL,
  `title` varchar(500) NOT NULL,
  `notes` text DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `due_time` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `completed_at` datetime DEFAULT NULL,
  `last_completed_at` datetime DEFAULT NULL,
  `recurrence_rule` varchar(255) DEFAULT NULL,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `archived_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tasks_project` (`project_id`),
  KEY `idx_tasks_due` (`due_date`),
  KEY `idx_tasks_completed` (`completed_at`),
  KEY `idx_tasks_folder` (`folder_id`),
  KEY `idx_tasks_archived` (`archived`),
  KEY `idx_tasks_archived_at` (`archived_at`),
  FULLTEXT KEY `ftx_tasks_title_notes` (`title`,`notes`),
  CONSTRAINT `fk_tasks_folder` FOREIGN KEY (`folder_id`) REFERENCES `folders` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tasks_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES
(1,5,NULL,'Cumpleaños Nuria Pet',NULL,'2027-03-03',NULL,'2026-03-03 15:36:58',NULL,'2026-03-03 19:37:19','FREQ=YEARLY;INTERVAL=1',0,NULL),
(2,5,NULL,'Cumpleaños Oliver Concheiro',NULL,'2027-03-03',NULL,'2026-03-03 15:37:53',NULL,'2026-03-03 19:37:22','FREQ=YEARLY;INTERVAL=1',0,NULL),
(3,5,NULL,'Cumpleaños Iria',NULL,'2026-07-25',NULL,'2026-03-03 15:56:21',NULL,NULL,'FREQ=YEARLY',0,NULL),
(4,5,NULL,'Cumpleaños Paula',NULL,'2026-06-15',NULL,'2026-03-03 15:57:29',NULL,NULL,'FREQ=Yearly',0,NULL),
(5,5,NULL,'Cumpleaños Noemí',NULL,'2026-09-21',NULL,'2026-03-03 16:00:19',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(6,5,NULL,'Cumpleaños Raúl',NULL,'2026-08-03',NULL,'2026-03-03 16:00:51',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(19,NULL,3,'Paseo Beni',NULL,'2026-03-18',NULL,'2026-03-03 23:25:40',NULL,'2026-03-17 22:28:07','FREQ=DAILY;INTERVAL=1',0,NULL),
(29,7,NULL,'01 - Vaciado bandejas entrada',NULL,'2026-03-27',NULL,'2026-03-04 20:27:08',NULL,'2026-03-17 23:02:58','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1',0,NULL),
(30,7,NULL,'02 - Revisión lista NextActions',NULL,'2026-03-20',NULL,'2026-03-04 20:48:26',NULL,'2026-03-13 21:12:39','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1',0,NULL),
(31,7,NULL,'03 - Revisión  Agenda (eventos futuros)',NULL,'2026-03-20',NULL,'2026-03-04 20:50:57',NULL,'2026-03-13 21:12:39','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1',0,NULL),
(32,7,NULL,'04 - Revisión Agenda (eventos pasados)',NULL,'2026-03-20',NULL,'2026-03-04 20:51:46',NULL,'2026-03-13 21:12:38','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1',0,NULL),
(33,7,NULL,'05 - Revisión lista EnEspera',NULL,'2026-03-20',NULL,'2026-03-04 20:52:12',NULL,'2026-03-13 21:12:37','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1',0,NULL),
(34,7,NULL,'06 - Revisión lista proyectos',NULL,'2026-03-20',NULL,'2026-03-04 20:53:41',NULL,'2026-03-13 21:12:36','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1',0,NULL),
(35,7,NULL,'07 - Revisión listas ADTV/SomeTime',NULL,'2026-03-20',NULL,'2026-03-04 20:58:55',NULL,'2026-03-13 21:12:35','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1',0,NULL),
(36,7,NULL,'08 - Revisión listas comprobación',NULL,'2026-03-20',NULL,'2026-03-04 21:42:54',NULL,'2026-03-13 21:12:34','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1',0,NULL),
(37,7,NULL,'09 - Análisis sistema GTD',NULL,'2026-03-20',NULL,'2026-03-04 21:45:00',NULL,'2026-03-13 21:12:33','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1',0,NULL),
(38,7,NULL,'10 - Fase creativa: Brainstorming para añadir nuevas ideas',NULL,'2026-03-20',NULL,'2026-03-04 21:46:18',NULL,'2026-03-13 21:12:32','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1',0,NULL),
(40,7,NULL,'00 - Revisión semanal GTD',NULL,'2026-03-20',NULL,'2026-03-04 21:56:11',NULL,'2026-03-13 21:12:32','FREQ=WEEKLY;BYDAY=FR;INTERVAL=1',0,NULL),
(50,NULL,2,'10.000 días desde 2/03/2001',NULL,'2028-07-18',NULL,'2026-03-05 19:01:57',NULL,NULL,NULL,0,NULL),
(51,NULL,9,'Honorarios CITIC',NULL,NULL,NULL,'2026-03-05 21:54:32','2026-03-17 13:44:59',NULL,NULL,0,NULL),
(53,NULL,6,'Revisar publicación Complementos Excelencia Xunta','http://www.acsug.es/gl/search/node/excelencia','2027-02-15',NULL,'2026-03-06 22:33:44',NULL,NULL,'FREQ=YEARLY;INTERVAL=4',0,NULL),
(56,9,NULL,'Santa Paula',NULL,'2027-01-26',NULL,'2026-03-06 22:43:26',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(61,9,NULL,'San Marcos',NULL,'2026-05-25',NULL,'2026-03-06 23:00:31',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(69,12,NULL,'Rondallas',NULL,NULL,NULL,'2026-03-08 10:46:36',NULL,NULL,NULL,0,NULL),
(70,13,NULL,'Preparar presentacion normativa',NULL,'2026-03-09',NULL,'2026-03-08 11:08:21','2026-03-09 13:02:12',NULL,NULL,0,NULL),
(71,13,NULL,'Reunión con gerente residencias (hora: 13:30)',NULL,'2026-03-10',NULL,'2026-03-08 11:09:48','2026-03-10 16:10:25',NULL,NULL,0,NULL),
(75,15,NULL,'Enviar correo confirmando desascripcion CITIC',NULL,NULL,NULL,'2026-03-08 11:24:03','2026-03-09 13:01:31',NULL,NULL,0,NULL),
(76,15,NULL,'Concretar reunión con Fernando para confirmar inexistencia problemas',NULL,NULL,NULL,'2026-03-08 11:24:35','2026-03-09 13:01:16',NULL,NULL,0,NULL),
(77,15,NULL,'Solicitar adscripción CITEEC',NULL,NULL,NULL,'2026-03-08 11:24:55',NULL,NULL,NULL,0,NULL),
(78,16,NULL,'Curso Imatus - Apps Seguridad','(16:00 - 20:00)','2026-04-07',NULL,'2026-03-09 11:17:48',NULL,NULL,NULL,0,NULL),
(79,16,NULL,'Preparar transparencias con apps de seguridad',NULL,'2026-03-30',NULL,'2026-03-09 11:18:47',NULL,NULL,NULL,0,NULL),
(85,15,NULL,'Confirmación desadscripción CITIC (EnEspera desde 09/03/2026)',NULL,NULL,NULL,'2026-03-09 12:01:47',NULL,NULL,NULL,0,NULL),
(86,21,NULL,'Comprar malla antihierba',NULL,NULL,NULL,'2026-03-09 12:15:40',NULL,NULL,NULL,0,NULL),
(87,21,NULL,'Colocar malla antihierba y fijación exterior',NULL,NULL,NULL,'2026-03-09 12:16:12',NULL,NULL,NULL,0,NULL),
(88,21,NULL,'Cubrir malla con piedra blanca',NULL,NULL,NULL,'2026-03-09 12:16:29',NULL,NULL,NULL,0,NULL),
(89,21,NULL,'Rellenar maceta con tierra + tierra vegetal',NULL,NULL,NULL,'2026-03-09 12:17:07',NULL,NULL,NULL,0,NULL),
(90,21,NULL,'Agujerear maceta para drenaje de agua',NULL,NULL,NULL,'2026-03-09 12:17:28',NULL,NULL,NULL,0,NULL),
(91,21,NULL,'Comprar y colocar plantas decorativas',NULL,NULL,NULL,'2026-03-09 12:17:42',NULL,NULL,NULL,0,NULL),
(92,NULL,16,'Recoger cerezo en vivero',NULL,NULL,NULL,'2026-03-10 16:20:44','2026-03-13 11:04:50',NULL,NULL,0,NULL),
(94,NULL,17,'Tramitar dieta de O Camiño do Inglés a través de FUAC',NULL,NULL,NULL,'2026-03-10 19:18:02','2026-03-11 10:59:56',NULL,NULL,0,NULL),
(95,NULL,17,'Tramitar dieta comida Ferrol en Navidad a través de FUAC',NULL,NULL,NULL,'2026-03-10 19:18:29','2026-03-11 10:59:52',NULL,NULL,0,NULL),
(96,NULL,16,'Actualizar fichero saldos.xlsx',NULL,'2026-03-28',NULL,'2026-03-10 20:32:23',NULL,NULL,'FREQ=MONTHLY;INTERVAL=1',0,NULL),
(97,NULL,17,'Nómina UDC',NULL,'2026-03-28',NULL,'2026-03-10 20:37:19',NULL,NULL,'FREQ=MONTHLY;INTERVAL=1',0,NULL),
(98,NULL,17,'Configurar acceso VPN en el router del despacho de Alberto en CITEEC',NULL,NULL,NULL,'2026-03-10 21:09:31',NULL,NULL,NULL,0,NULL),
(100,30,NULL,'Upload',NULL,NULL,NULL,'2026-03-10 21:12:26',NULL,NULL,NULL,0,NULL),
(101,NULL,16,'Reservar mesa para 9 en A de Alberto (cumpleaños tía Mari) para Sábado 21','981 90 74 11',NULL,NULL,'2026-03-10 21:14:10','2026-03-13 11:04:46',NULL,NULL,0,NULL),
(102,NULL,23,'Actualizar documento con fechas de exámenes siguiente curso',NULL,'2026-08-01',NULL,'2026-03-10 21:17:15',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(103,NULL,23,'Actualizar horarios siguiente curso académico',NULL,'2026-08-01',NULL,'2026-03-10 21:18:13',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(104,NULL,16,'Recordar a Aluminios Prado Presupuesto mosquiteras',NULL,NULL,NULL,'2026-03-10 22:37:33',NULL,NULL,NULL,0,NULL),
(106,NULL,16,'Recordar fontanero desatasque desague',NULL,NULL,NULL,'2026-03-10 22:39:41',NULL,NULL,NULL,0,NULL),
(119,NULL,9,'FUAC: comida Néboa (89,90€) desde (11/03/26)',NULL,NULL,NULL,'2026-03-11 10:00:34',NULL,NULL,NULL,0,NULL),
(121,25,NULL,'Your Digital Life (Carl Pullein)',NULL,NULL,NULL,'2026-03-11 20:31:10',NULL,NULL,NULL,0,NULL),
(122,NULL,2,'Ingreso Paula (dolor abdominal + bilirrubina alta)',NULL,'2026-03-12',NULL,'2026-03-11 20:55:52','2026-03-13 18:43:15',NULL,NULL,0,NULL),
(123,NULL,17,'Revisar solicitud GitHub Copilot','https://github.com/settings/education/benefits',NULL,NULL,'2026-03-11 21:15:47','2026-03-15 00:44:28',NULL,NULL,0,NULL),
(126,12,NULL,'Ídolos (motogp)',NULL,NULL,NULL,'2026-03-13 15:05:12',NULL,NULL,NULL,0,NULL),
(131,13,NULL,'Confirmar interés Carlos en cátedra interuniversitaria con Vigo',NULL,NULL,NULL,'2026-03-13 21:12:09',NULL,NULL,NULL,0,NULL),
(132,13,NULL,'Confirmar interés en desarrollo aplicación screening inteligente',NULL,NULL,NULL,'2026-03-13 21:12:33',NULL,NULL,NULL,0,NULL),
(134,9,NULL,'Santa Noemí',NULL,'2026-06-04',NULL,'2026-03-13 21:43:49',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(136,9,NULL,'Santo Iria',NULL,'2026-09-13',NULL,'2026-03-13 21:45:04',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(137,9,NULL,'San Raúl',NULL,'2026-12-30',NULL,'2026-03-13 21:46:02',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(138,NULL,16,'Escoger fotos comunión de Raúl','https://joselagaresfotografia.pixieset.com/comuninral/   (contraseña: 04082024)',NULL,NULL,'2026-03-14 08:40:30',NULL,NULL,NULL,0,NULL),
(139,NULL,17,'Elecciones de PDI al Claustro UDC','Profesorado Permanente (se pueden votar a 14 personas):\r\nBolón Canedo, Verónica\r\nCabalar Fernández, José Pedro\r\nCacheda Seijo, Fidel\r\nFernández Blanco, Enrique\r\nFernández Iglesias, Diego\r\nGestal Pose, Marcos\r\nGuijarro Berdiñas, Berta María\r\nMato Abad, Virginia\r\nPedreira Fernández, Óscar\r\nPérez Vega, Gilberto\r\nRodríguez Yáñez, Santiago\r\nSaavedra Places, María de los Ángeles\r\nSuárez Garaboa, Sonia María\r\nVidal Martín, Concepción','2026-03-17',NULL,'2026-03-14 23:34:46','2026-03-17 10:46:38',NULL,NULL,0,NULL),
(140,NULL,16,'Pedir piedra de cocinar a Mari Carmen',NULL,'2026-03-30',NULL,'2026-03-14 23:37:20',NULL,NULL,NULL,0,NULL),
(141,NULL,5,'Foto Mes',NULL,'2026-03-20',NULL,'2026-03-14 23:41:12',NULL,NULL,'FREQ=MONTHLY;INTERVAL=1',0,NULL),
(142,NULL,6,'Renovación GitHub Copilot PRO (caduca el 15 de Marzo)',NULL,'2028-03-01',NULL,'2026-03-15 10:34:47',NULL,NULL,NULL,0,NULL),
(143,5,NULL,'Cumpleaños Candela Jiménez',NULL,'2026-05-12',NULL,'2026-03-15 10:43:17',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(144,NULL,16,'Fotografías carnet Paula',NULL,NULL,NULL,'2026-03-15 21:11:50','2026-03-15 22:11:55',NULL,NULL,0,NULL),
(145,NULL,17,'Tramitar pago móvil Samsung S24 FE',NULL,NULL,NULL,'2026-03-15 21:14:11',NULL,NULL,NULL,0,NULL),
(146,NULL,16,'Bautizo Gaby (13:00)',NULL,NULL,NULL,'2026-03-15 21:18:56',NULL,NULL,NULL,0,NULL),
(147,NULL,16,'Pedir cita en taller para cambio ruedas y aceite',NULL,NULL,NULL,'2026-03-16 06:46:23',NULL,NULL,NULL,0,NULL),
(148,NULL,6,'Cambiar aceite cortacesped',NULL,'2027-03-01',NULL,'2026-03-16 06:47:23',NULL,'2026-03-16 07:48:04','FREQ=YEARLY;INTERVAL=1',0,NULL),
(151,NULL,6,'Torre de Hércules en verde: San Patricio cada año','Enlace: https://www.google.com/calendar/event?eid=dG9kb2lzdDY4MDUwMjRpMjIwMjIwNDYzNHVmNTg0NmQ0MDdhNzQ0MDEwYTQ5MGZjYTVhMmMzNjdlZV8yMDI2MDMxNiBtZ2VzdGFsQG0','2027-03-16',NULL,'2026-03-16 12:28:59',NULL,'2026-03-16 20:18:49','FREQ=YEARLY;INTERVAL=1',0,NULL),
(152,NULL,4,'Adiestramiento Beni. Gaia (Sueiro)','Horario: 19:00-20:00','2026-03-20','19:00:00','2026-03-16 12:28:59',NULL,NULL,'FREQ=WEEKLY;INTERVAL=1',0,NULL),
(153,5,NULL,'Cumpleaños de Mari Carmen Carrillo García','Enlace: https://www.google.com/calendar/event?eid=dG9kb2lzdDY4MDUwMjRpMjIwNzY4MTQwNHUwYjlkOGQ4Mzk3NDQ0M2I4YWRkOGYzYzhlNGQ5Njg0MV8yMDI2MDMyMSBtZ2VzdGFsQG0','2026-03-21',NULL,'2026-03-16 12:29:29',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(155,NULL,2,'Tribunales MUNICS','Enlace: https://www.google.com/calendar/event?eid=M3A4amI2ZTRkamE3bDhibmZibm92NHFwNmQgbWdlc3RhbEBt','2026-03-24',NULL,'2026-03-16 12:29:29',NULL,NULL,NULL,0,NULL),
(156,NULL,2,'Talleres Varela: Cambio Aceite y Ruedas (Audi A3)','Enlace: https://www.google.com/calendar/event?eid=MmlpZnM5a2Q1cjl0N2tnNTgydHAxb20wajAgbWdlc3RhbEBt','2026-03-25','09:00:00','2026-03-16 12:29:29',NULL,NULL,NULL,0,NULL),
(158,8,NULL,'Cita Médica Paula para solicitar Revisión especialista Hematología (Centro Salud Mallos: presencial)','Enlace: https://www.google.com/calendar/event?eid=MG8wNG5qYWpoNTJzdTE2cW1tZ2J1YXAwbjAgbWdlc3RhbEBt','2026-03-26',NULL,'2026-03-16 12:29:29',NULL,NULL,NULL,0,NULL),
(159,27,NULL,'Reunión 3 - Talentos inclusivos (IES REGO da Trabe - adaptador merienda)','Ubicación: https://us02web.zoom.us/j/2915069969?pwd=TU8xcUFqdGtQdTYwYkthY3Nyb0FEUT09\r\n\r\nEnlace: https://www.google.com/calendar/event?eid=MzRidGo5cDVpb29odW41bTIzc3YzM2owdjIgbWdlc3RhbEBt','2026-03-26','12:30:00','2026-03-16 12:29:29',NULL,NULL,NULL,0,NULL),
(161,28,NULL,'Pedir dias asuntos propios para ir a Bayuela',NULL,NULL,NULL,'2026-03-16 13:37:18',NULL,NULL,NULL,0,NULL),
(163,28,NULL,'Confirmar fechas viaje',NULL,NULL,NULL,'2026-03-16 19:17:20',NULL,NULL,NULL,0,NULL),
(164,28,NULL,'Cubrir papel delegación docencia (Julián)',NULL,NULL,NULL,'2026-03-16 19:17:42',NULL,NULL,NULL,0,NULL),
(165,28,NULL,'Reservar comida (Ávila?)',NULL,NULL,NULL,'2026-03-16 19:18:06',NULL,NULL,NULL,0,NULL),
(166,30,NULL,'Scarpeta (serie Nicole Kidman - 8 Episodios )',NULL,NULL,NULL,'2026-03-16 19:24:12',NULL,NULL,NULL,0,NULL),
(167,30,NULL,'El joven Sherlock (serie - 8 episodios)',NULL,NULL,NULL,'2026-03-16 19:24:48',NULL,NULL,NULL,0,NULL),
(173,NULL,5,'Actualizar fichero saldos.xlsx','Enlace: https://www.google.com/calendar/event?eid=dG9kb2lzdDY4MDUwMjRpMzg4ODk0MDE2NHVmZDA1NWE3NWE4MTY0MTM5YWQ0NDhiNTE5MDQ5YTlkNF8yMDI2MDMyOCBtZ2VzdGFsQG0','2026-03-28',NULL,'2026-03-16 19:36:37',NULL,NULL,'FREQ=MONTHLY;INTERVAL=1',0,NULL),
(174,NULL,5,'Revisar listado películas para comprobar si están disponibles para descargar','Enlace: https://www.google.com/calendar/event?eid=dG9kb2lzdDY4MDUwMjRpNTI2NTQ5MTR1NWU5NDgyOGZlNTYxNDcxZWE1MDVhODE2Y2Q4MjE5NTdfMjAyNjAzMjggbWdlc3RhbEBt','2026-03-28',NULL,'2026-03-16 19:36:37',NULL,NULL,'FREQ=MONTHLY;INTERVAL=1',0,NULL),
(182,NULL,17,'Responder Margarita Ordaix revisión artículo',NULL,NULL,NULL,'2026-03-16 22:27:34','2026-03-17 08:43:10',NULL,NULL,0,NULL),
(183,NULL,6,'Cambiar filtro aceite cortacesped',NULL,'2026-03-01',NULL,'2026-03-16 22:31:38',NULL,NULL,'FREQ=WEEKLY;INTERVAL=2',0,NULL),
(185,31,NULL,'Parque Cabárceno',NULL,NULL,NULL,'2026-03-16 22:57:11',NULL,NULL,NULL,0,NULL),
(186,31,NULL,'Marcelle',NULL,NULL,NULL,'2026-03-16 22:57:17',NULL,NULL,NULL,0,NULL),
(187,31,NULL,'Lagos de Covadonga',NULL,NULL,NULL,'2026-03-16 22:57:23',NULL,NULL,NULL,0,NULL),
(188,31,NULL,'Cuevas El Soplo (Cantabria)',NULL,NULL,NULL,'2026-03-16 22:57:32',NULL,NULL,NULL,0,NULL),
(189,31,NULL,'San Juan de Gaztelugatxe','http://www.sanjuandegaztelugatxe.com/',NULL,NULL,'2026-03-16 22:57:56',NULL,NULL,NULL,0,NULL),
(190,31,NULL,'Hayedo de Busmayor','http://www.rutinasvarias.com/2017/02/21/hayedo-busmayor-senda-del-faxeiral',NULL,NULL,'2026-03-16 22:59:03',NULL,NULL,NULL,0,NULL),
(191,31,NULL,'Faedo Ciñera',NULL,NULL,NULL,'2026-03-16 22:59:17',NULL,NULL,NULL,0,NULL),
(192,31,NULL,'Lagartera (Toledo)',NULL,NULL,NULL,'2026-03-16 22:59:30',NULL,NULL,NULL,0,NULL),
(193,31,NULL,'Alcalá de Henares (Madrid)',NULL,NULL,NULL,'2026-03-16 22:59:48',NULL,NULL,NULL,0,NULL),
(194,31,NULL,'Cuevas de Valporquero',NULL,NULL,NULL,'2026-03-16 23:00:04',NULL,NULL,NULL,0,NULL),
(195,31,NULL,'Castro de Santa Tegra',NULL,NULL,NULL,'2026-03-16 23:00:21','2026-03-17 00:00:24',NULL,NULL,0,NULL),
(196,NULL,23,'MUNICS: Convocatoria de fin de cuadrimestre (tribunal titular)','Asunto: Fw: MUniCS: TFM: Convocatoria de fin de cuadrimestre (tribunal titular)\r\nRemitente: Marcos Gestal Pose <mgestal@udc.es>\r\nFecha: Mon, 16 Mar 2026 23:23:12 +0000\r\nEnlace Gmail: https://mail.google.com/mail/u/0/#all/19cf8f61476ebd3a\r\n\r\nSnippet:\r\nEnviado desde Outlook para Android From: TFG/TFM EET &lt;teleco.tfg.tfm@uvigo.gal&gt; Sent: Monday, March 16, 2026 8:30:00 AM To: Jorge Marcos Acevedo &lt;acevedo@uvigo.gal&gt;; Marcos Gestal Pose &lt;',NULL,NULL,'2026-03-16 23:23:47','2026-03-17 08:55:40',NULL,NULL,0,NULL),
(201,27,NULL,'Reunión 4 - Talentos inclusivos (IES REGO da Trabe - adaptador merienda)','Ubicación: https://us02web.zoom.us/j/2915069969?pwd=TU8xcUFqdGtQdTYwYkthY3Nyb0FEUT09','2026-04-30','13:00:00','2026-03-17 08:11:50',NULL,NULL,NULL,0,NULL),
(202,27,NULL,'Reunión 5 - Talentos inclusivos (IES REGO da Trabe - adaptador merienda)','Ubicación: https://us02web.zoom.us/j/2915069969?pwd=TU8xcUFqdGtQdTYwYkthY3Nyb0FEUT09','2026-05-14','12:30:00','2026-03-17 08:12:54',NULL,NULL,NULL,0,NULL),
(203,27,NULL,'Reunión 6 - Talentos inclusivos (IES REGO da Trabe - adaptador merienda)','Ubicación: https://us02web.zoom.us/j/2915069969?pwd=TU8xcUFqdGtQdTYwYkthY3Nyb0FEUT09','2026-06-04',NULL,'2026-03-17 08:13:21',NULL,NULL,NULL,0,NULL),
(204,NULL,6,'Lluvia estrellas: Gemínidas',NULL,'2026-12-12',NULL,'2026-03-17 09:57:08',NULL,NULL,'FREQ=YEARLY;INTERVAL=1',0,NULL),
(205,33,NULL,'Hablar con Alberto para organizar nueva query',NULL,NULL,NULL,'2026-03-17 12:36:09',NULL,NULL,NULL,0,NULL),
(206,33,NULL,'Redactar artículo (incluir Jose y Juanra como autores)',NULL,NULL,NULL,'2026-03-17 12:36:20',NULL,NULL,NULL,0,NULL),
(207,33,NULL,'Enviar a Sensors',NULL,NULL,NULL,'2026-03-17 12:36:49',NULL,NULL,NULL,0,NULL),
(208,34,NULL,'Charla LLM: Instituto Cabo Ortegal','Horario: 16:00 - 18:00','2026-04-20','16:00:00','2026-03-17 12:48:21',NULL,NULL,NULL,0,NULL),
(209,34,NULL,'Charla LLM: Instituto Cabo Ortegal',NULL,'2026-04-27','16:00:00','2026-03-17 12:49:11',NULL,NULL,NULL,0,NULL),
(210,34,NULL,'Revisar y completar con ejemplos transparencias charla LLM',NULL,'2026-04-06',NULL,'2026-03-17 12:50:01',NULL,NULL,NULL,0,NULL),
(211,34,NULL,'Enviar correo responsable instituto confirmando disponibilidad, aula',NULL,'2026-04-06',NULL,'2026-03-17 12:50:41',NULL,NULL,NULL,0,NULL),
(212,35,NULL,'Gestionar subida a Google Calendar de tareas creadas con fecha (o modificacion fecha)',NULL,NULL,NULL,'2026-03-17 12:53:07',NULL,NULL,NULL,0,NULL),
(213,35,NULL,'Decidir comportamiento Menú lateral: próximo? Agenda (tareas con etiqueta agenda)? Checkbox mostrar etiquetadas como agenda en Calendario.html?',NULL,NULL,NULL,'2026-03-17 12:53:57','2026-03-17 23:55:51',NULL,NULL,0,NULL),
(214,35,NULL,'Decidir multiusuario',NULL,NULL,NULL,'2026-03-17 12:54:07',NULL,NULL,NULL,0,NULL),
(215,35,NULL,'Proteger acceso a la URL desde apache',NULL,NULL,NULL,'2026-03-17 12:54:32','2026-03-17 22:09:49',NULL,NULL,0,NULL),
(216,35,NULL,'Añadir fecha a las tareas en la vista calendar.html',NULL,NULL,NULL,'2026-03-17 12:57:38','2026-03-17 22:24:46',NULL,NULL,0,NULL),
(217,35,NULL,'Decidir qué hacer con tareas ya realizadas (archivo? Admin?)',NULL,NULL,NULL,'2026-03-17 13:05:09','2026-03-17 23:55:25',NULL,NULL,0,NULL),
(218,35,NULL,'Docker',NULL,NULL,NULL,'2026-03-17 14:43:26',NULL,NULL,NULL,0,NULL),
(219,35,NULL,'Pedir Manual de Usuario a ChatGPT',NULL,NULL,NULL,'2026-03-17 14:43:57',NULL,NULL,NULL,0,NULL),
(220,NULL,NULL,'Recoger paquete','Asunto: Recoger paquete @fic\nRemitente: Marcos Gestal Pose <marcos.gestal@udc.es>\nFecha: Tue, 17 Mar 2026 13:53:09 +0000\nEnlace Gmail: https://mail.google.com/mail/u/0/#all/19cfc126f77b2e1b\n\nSnippet:\nDe: Conserxaría da Facultade de Informática &lt;conserxaria.fic@udc.gal&gt; Enviado: martes, marzo 17, 2026 2:21:51 pm Para: María José Lombardía Cortiña &lt;maria.jose.lombardia@udc.es&gt;; Virginia',NULL,NULL,'2026-03-17 15:25:30',NULL,NULL,NULL,0,NULL),
(221,36,NULL,'Comprar regalo',NULL,NULL,NULL,'2026-03-17 15:27:44',NULL,NULL,NULL,0,NULL),
(222,36,NULL,'Fotos previas bautizo',NULL,NULL,NULL,'2026-03-17 15:28:11',NULL,NULL,NULL,0,NULL),
(223,36,NULL,'Bautizo Gabi',NULL,'2026-04-11','13:00:00','2026-03-17 15:29:05',NULL,NULL,NULL,0,NULL),
(224,NULL,18,'Robot cortacesped',NULL,NULL,NULL,'2026-03-17 15:31:55',NULL,NULL,NULL,0,NULL),
(225,37,NULL,'Desagüe acera garaje',NULL,NULL,NULL,'2026-03-17 15:34:07',NULL,NULL,NULL,0,NULL),
(226,37,NULL,'Mesa / Caballetes almacén',NULL,NULL,NULL,'2026-03-17 15:34:41',NULL,NULL,NULL,0,NULL),
(227,37,NULL,'Enganches Comedero y Bebedero en gallinero',NULL,NULL,NULL,'2026-03-17 15:35:30',NULL,NULL,NULL,0,NULL),
(228,NULL,18,'Losetas camino almacén',NULL,NULL,NULL,'2026-03-17 15:36:58',NULL,NULL,NULL,0,NULL),
(229,35,NULL,'Review GTD. Añadir al punto 7 lista de tareas no incluidas en proyectos',NULL,NULL,NULL,'2026-03-17 15:39:25','2026-03-17 22:15:00',NULL,NULL,0,NULL),
(230,35,NULL,'Arreglar ancho card vista móvil de proximo.html',NULL,NULL,NULL,'2026-03-17 15:42:13','2026-03-17 22:18:22',NULL,NULL,0,NULL),
(231,NULL,NULL,'Revisar configuración sonido aula Máster',NULL,'2026-03-18',NULL,'2026-03-17 18:16:42',NULL,NULL,NULL,0,NULL),
(232,NULL,NULL,'Certificado empadronamiento Culleredo para renovación DNI',NULL,NULL,NULL,'2026-03-17 19:47:47',NULL,NULL,NULL,0,NULL),
(236,NULL,4,'Revisión semanal GTD',NULL,'2026-03-20','13:00:00','2026-03-17 21:44:44',NULL,NULL,'FREQ=WEEKLY;INTERVAL=1',0,NULL),
(237,NULL,5,'Nómina UDC',NULL,'2026-03-28',NULL,'2026-03-17 22:17:36',NULL,NULL,'FREQ=MONTHLY;INTERVAL=1',0,NULL),
(238,NULL,16,'Recoger el segundo cerezo en el vivero',NULL,NULL,NULL,'2026-03-17 22:37:55',NULL,NULL,NULL,0,NULL),
(239,NULL,16,'Conseguir plato (o lámina de pizarra) para bonsai',NULL,NULL,NULL,'2026-03-17 22:38:31',NULL,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Dumping events for database 'gtd'
--

--
-- Dumping routines for database 'gtd'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-18  0:07:01
